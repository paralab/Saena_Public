### `src/core/DistMatrix/`

This folder contains the source code for the various partial specializations of
the `DistMatrix` class; please see `include/El/core/DistMatrix/` for the
corresponding header-level prototypes and a detailed README explaining the 
various data distributions.
